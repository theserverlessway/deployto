# AWSDeploy

Simple Deployment tool for various AWS Services.